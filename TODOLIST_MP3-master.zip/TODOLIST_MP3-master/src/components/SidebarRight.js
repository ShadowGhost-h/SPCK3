import React from 'react'

const SidebarRight = () => {
    return (
        <div>SidebarRight</div>
    )
}

export default SidebarRight