import React from 'react'

const Personal = () => {
    return (
        <div>Personal</div>
    )
}

export default Personal