### API version local

- Clone về
- Mở project
- npm start